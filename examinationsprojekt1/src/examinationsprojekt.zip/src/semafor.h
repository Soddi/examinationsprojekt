/*
 * semafor.h
 *
 * Created: 2014-03-17 17:21:43
 *  Author: ac0542
 */ 


#ifndef SEMAFOR_H_
#define SEMAFOR_H_

extern xSemaphoreHandle semafor_signal;

#endif /* SEMAFOR_H_ */