/*
 * task1.h
 *
 * Created: 2014-03-17 17:18:06
 *  Author: ac0542
 */ 


#ifndef TASK1_H_
#define TASK1_H_

#include <asf.h>

void task1(void*);

#endif /* TASK1_H_ */