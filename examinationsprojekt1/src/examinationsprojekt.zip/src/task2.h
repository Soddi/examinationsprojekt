/*
 * task2.h
 *
 * Created: 2014-03-17 17:18:16
 *  Author: ac0542
 */ 


#ifndef TASK2_H_
#define TASK2_H_

#include <asf.h>

void task2(void*);

#endif /* TASK2_H_ */