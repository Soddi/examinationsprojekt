/*
 * task1.c
 *
 * Created: 2014-03-17 17:17:46
 *  Author: ac0542
 */ 

#include "task1.h"
#include "semafor.h"

/**
* Task1 with the function that give the smepahore every other second.
*/
void task1(void *p)
{
	for(;;)
	{
		printf("Task1 skickar signal och 'ger' semaforen till task2\n");
		/* Makro to give a semaphore. The sempahpore must
		have been created by calling vSemaphoreCreateBinary()
		*/
		xSemaphoreGive(semafor_signal);
		printf("Task1 slutar ge signal\n");
		printf("\n");
		/* Every other second task1 signals to task2 */
		vTaskDelay(2000);
	}
}