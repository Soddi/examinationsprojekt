/*
 * task2.c
 *
 * Created: 2014-03-17 17:18:26
 *  Author: ac0542
 */ 

#include "task2.h"
#include "semafor.h"

/**
* A function for task2 printing a statement when task2 is being executed
*/
static void task2_uppgift(void)
{
	printf("Task2 g�r sin uppgift\n");
}

/**
* Task2 "takes" the semaphore and finishes the execution
*/
void task2(void *p)
{
	for(;;)
	{
		/* macro to take a semaphore. It must have been
		created with
		vSemaphoreCreateBinary().
		xSempahoreTake reurns pdTRUE if the semaphore was
		recived,
		pdFALSE if xBlockTime timed out before the semaphore
		became availible. */
		if(xSemaphoreTake(semafor_signal, portMAX_DELAY))
		{
			printf("Task2 'tar' semaforen\n");
			task2_uppgift();
			printf("Task2 har exekverats f�rdigt!\n");
		}
	}
}